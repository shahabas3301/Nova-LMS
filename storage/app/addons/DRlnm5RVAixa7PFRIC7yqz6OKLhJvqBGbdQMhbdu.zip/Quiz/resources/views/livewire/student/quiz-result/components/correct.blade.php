<span>
    <span class="am-ans-detail_correct"><i class="am-icon-check-circle06"></i></span>
    <em>{{ __('quiz::quiz.quiz_results_correct') }}</em>
</span>