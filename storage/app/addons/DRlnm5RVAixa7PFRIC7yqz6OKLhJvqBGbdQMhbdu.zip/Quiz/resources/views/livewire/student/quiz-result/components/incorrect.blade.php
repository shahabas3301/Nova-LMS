<span>
    <span class="am-ans-detail_incorrect"><i class="am-icon-multiply-02"></i></span>
    <em>{{ __('quiz::quiz.quiz_results_incorrect') }}</em>
</span>