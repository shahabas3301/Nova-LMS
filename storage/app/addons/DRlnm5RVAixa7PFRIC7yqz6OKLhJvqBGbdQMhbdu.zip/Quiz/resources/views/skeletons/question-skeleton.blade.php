<div class="am-favourites_skeleton">
    @for($i = 0; $i < $total; $i++)
        <div class="am-favourites_list"></div>
    @endfor
</div>
