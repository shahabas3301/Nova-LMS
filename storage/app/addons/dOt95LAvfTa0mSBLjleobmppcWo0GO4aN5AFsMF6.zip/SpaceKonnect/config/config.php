<?php

return [
    'name' => 'SpaceKonnect',
];
