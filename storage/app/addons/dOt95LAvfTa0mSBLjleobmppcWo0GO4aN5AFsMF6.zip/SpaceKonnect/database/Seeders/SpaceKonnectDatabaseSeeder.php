<?php

namespace Modules\SpaceKonnect\Database\Seeders;

use Illuminate\Database\Seeder;

class SpaceKonnectDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
