<?php

return [
    'name' => 'MeetFusion',
];
