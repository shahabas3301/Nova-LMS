<?php

return [
    'name'          => 'IPManager',
    'db_prefix'     => 'ipmanager_'
];
