    <!-- Skeleton start -->
  <div class="am-assignlist_wrap am-assignlist-skeleton">
    <ul>
    @for($i = 0; $i < $total; $i++)
        <li>
            <div class="am-assignlist_item">
                <span></span>
                <div class="am-assignlist_item_content">
                    <div class="am-assignlist_coursename">
                        <div class="am-assignlist_coursetitle">
                            <span></span>
                            <em></em>
                        </div>
                        <div class="am-itemdropdown"></div>
                    </div>
                    <ul class="am-assignlist_item_footer">
                        <li>
                            <span></span>
                            <em></em>
                        </li>
                        <li>
                            <span></span>
                            <em></em>
                        </li>
                        <li>
                            <span></span>
                            <em></em>
                        </li>
                    </ul>
                </div>
            </div>
        </li>
    @endfor
    </ul>
</div> 
     <!-- Skeleton End -->