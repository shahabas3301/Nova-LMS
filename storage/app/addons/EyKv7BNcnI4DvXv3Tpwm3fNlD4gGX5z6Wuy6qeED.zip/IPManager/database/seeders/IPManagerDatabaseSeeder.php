<?php

namespace Modules\IPManager\Database\Seeders;

use Illuminate\Database\Seeder;

class IPManagerDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
