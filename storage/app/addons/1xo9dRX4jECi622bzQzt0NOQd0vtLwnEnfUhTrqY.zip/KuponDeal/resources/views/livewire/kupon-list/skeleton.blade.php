@for ($i = 0; $i < 5; $i++)
    <li>
        <div class="kd-coupon_skeleton">
            <div class="kd-coupon_header">
                <span>
                    <sup> </sup>
                    <em> </em>
                </span>
                <div class="kd-itemdropdown">
                </div>
            </div>
            <div class="kd-coupon_body">
                <em></em>
                <h3>
                    <span></span>
                </h3>
                <span></span>
            </div>
        </div>
    </li>
@endfor
