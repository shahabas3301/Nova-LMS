<?php

return [
    'name' => 'KuponDeal',
    'layout' => 'layouts.app',
];
