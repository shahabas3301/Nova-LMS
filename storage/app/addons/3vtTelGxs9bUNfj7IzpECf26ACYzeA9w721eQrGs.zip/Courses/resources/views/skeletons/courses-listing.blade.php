<tr>
    <td>
        <span class="cr-course-skeleton">
            <span></span>
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <strong>
                <em></em>
                <em></em>
                <em></em>
                <em></em>
                <em></em>
            </strong>
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <em></em>
            <span></span>
        </span>
    </td>
</tr>
<tr>
    <td>
        <span class="cr-course-skeleton">
            <span></span>
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <strong>
                <em></em>
                <em></em>
                <em></em>
                <em></em>
                <em></em>
            </strong>
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <em></em>
            <span></span>
        </span>
    </td>
</tr>
<tr>
    <td>
        <span class="cr-course-skeleton">
            <span></span>
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <strong>
                <em></em>
                <em></em>
                <em></em>
                <em></em>
                <em></em>
            </strong>
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <em></em>
            <span></span>
        </span>
    </td>
</tr>
<tr>
    <td>
        <span class="cr-course-skeleton">
            <span></span>
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <strong>
                <em></em>
                <em></em>
                <em></em>
                <em></em>
                <em></em>
            </strong>
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <em></em>
            <span></span>
        </span>
    </td>
</tr>
<tr>
    <td>
        <span class="cr-course-skeleton">
            <span></span>
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <strong>
                <em></em>
                <em></em>
                <em></em>
                <em></em>
                <em></em>
            </strong>
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <em></em>
            <span></span>
        </span>
    </td>
</tr>
<tr>
    <td>
        <span class="cr-course-skeleton">
            <span></span>
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <strong>
                <em></em>
                <em></em>
                <em></em>
                <em></em>
                <em></em>
            </strong>
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <em></em>
            <span></span>
        </span>
    </td>
</tr>
<tr>
    <td>
        <span class="cr-course-skeleton">
            <span></span>
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <strong>
                <em></em>
                <em></em>
                <em></em>
                <em></em>
                <em></em>
            </strong>
            <p></p>
        </span>
    </td>
    <td>
        <span class="cr-course-skeleton">
            <em></em>
            <span></span>
        </span>
    </td>
</tr>
