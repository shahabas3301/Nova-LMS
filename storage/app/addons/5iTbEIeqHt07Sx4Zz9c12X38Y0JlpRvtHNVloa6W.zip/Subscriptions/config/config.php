<?php

return [
    'name' => 'Subscriptions',
];
