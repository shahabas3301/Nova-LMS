<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create(config('upcertify.db_prefix').'certificates', function (Blueprint $table) {
            $table->id();
            $table->uuid('hash_id')->unique();
            $table->string('modelable_type');
            $table->unsignedBigInteger('modelable_id');
            $table->unsignedBigInteger('template_id');
            $table->json('wildcard_data')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists(config('upcertify.db_prefix').'certificates');
    }
};
