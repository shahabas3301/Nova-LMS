<svg xmlns="http://www.w3.org/2000/svg" width="72" height="72" viewBox="0 0 72 72" fill="none">
<path d="M3.81299 68.3918C25.1197 47.0851 47.1771 24.3226 68.5066 3.69824" stroke="#D9D9D9" stroke-width="6.46936" stroke-linecap="round" stroke-linejoin="round"/>
</svg>