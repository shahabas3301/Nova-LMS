<svg width="1161" height="717" viewBox="0 0 1161 717" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M40.5234 242.572V40.1016H243.003" stroke="#A1BFDB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M40.5234 20.1016H20.5234V40.1016H40.5234V20.1016Z" stroke="#A1BFDB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M80.5234 60.1094H60.5234V80.1094H80.5234V60.1094Z" stroke="#A1BFDB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M343.003 20.1016H60.5234V60.1016H20.5234V342.572" stroke="#A1BFDB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1120.52 242.572V40.1016H918.047" stroke="#A1BFDB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1120.52 40.1016H1140.52V20.1016L1120.52 20.1016V40.1016Z" stroke="#A1BFDB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1080.52 80.1094H1100.52V60.1094H1080.52V80.1094Z" stroke="#A1BFDB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1140.52 342.572V60.1016H1100.52V20.1016H818.047" stroke="#A1BFDB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M40.5234 473.629V676.099H243.003" stroke="#A1BFDB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M40.5234 676.102H20.5234V696.102H40.5234V676.102Z" stroke="#A1BFDB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M80.5234 636.09H60.5234V656.09H80.5234V636.09Z" stroke="#A1BFDB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M20.5234 373.629V656.099H60.5234V696.099H343.003" stroke="#A1BFDB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1120.52 473.629V676.099H918.047" stroke="#A1BFDB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1120.52 696.102H1140.52V676.102H1120.52V696.102Z" stroke="#A1BFDB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1080.52 656.078H1100.52V636.078H1080.52V656.078Z" stroke="#A1BFDB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M818.047 696.099H1100.52V656.099H1140.52V373.629" stroke="#A1BFDB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
