<svg xmlns="http://www.w3.org/2000/svg" width="141" height="141" viewBox="0 0 141 141" fill="none">
    <g clip-path="url(#clip0_17374_13714)">
        <path d="M3.13232 40.1382V4.61719H27.1338" stroke="#A1BFDB" stroke-width="1.06689" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M3.1321 1.1084H0.76123V4.61717H3.1321V1.1084Z" stroke="#A1BFDB" stroke-width="1.06689" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M7.8738 8.12793H5.50293V11.6367H7.8738V8.12793Z" stroke="#A1BFDB" stroke-width="1.06689" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M38.988 1.1084H5.50297V8.12594H0.76123V57.6821" stroke="#A1BFDB" stroke-width="1.06689" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M138.035 40.1382V4.61719H114.033" stroke="#A1BFDB" stroke-width="1.06689" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M138.035 4.61719H140.406V1.10842L138.035 1.10842V4.61719Z" stroke="#A1BFDB" stroke-width="1.06689" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M133.293 11.6367H135.664V8.12795H133.293V11.6367Z" stroke="#A1BFDB" stroke-width="1.06689" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M140.405 57.6821V8.12594H135.664V1.1084H102.179" stroke="#A1BFDB" stroke-width="1.06689" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M3.13232 101.553V137.074H27.1338" stroke="#A1BFDB" stroke-width="1.06689" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M3.1321 137.073H0.76123V140.582H3.1321V137.073Z" stroke="#A1BFDB" stroke-width="1.06689" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M7.8738 130.055H5.50293V133.563H7.8738V130.055Z" stroke="#A1BFDB" stroke-width="1.06689" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M0.76123 84.0088V133.565H5.50297V140.582H38.988" stroke="#A1BFDB" stroke-width="1.06689" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M138.035 101.553V137.074H114.033" stroke="#A1BFDB" stroke-width="1.06689" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M138.035 140.582H140.406V137.073H138.035V140.582Z" stroke="#A1BFDB" stroke-width="1.06689" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M133.293 133.563H135.664V130.055H133.293V133.563Z" stroke="#A1BFDB" stroke-width="1.06689" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M102.179 140.582H135.664V133.565H140.405V84.0088" stroke="#A1BFDB" stroke-width="1.06689" stroke-linecap="round" stroke-linejoin="round"/>
    </g>
    <defs>
        <clipPath id="clip0_17374_13714">
        <rect width="140" height="140" fill="white" transform="translate(0.583496 0.845703)"/>
        </clipPath>
    </defs>
</svg>