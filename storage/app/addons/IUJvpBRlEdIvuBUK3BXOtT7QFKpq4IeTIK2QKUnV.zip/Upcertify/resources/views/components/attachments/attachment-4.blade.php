<svg width="251" height="29" viewBox="0 0 251 29" fill="none">
    <g opacity="0.7" clip-path="url(#clip0_17374_13644)">
        <path d="M118.385 20.6532L124.952 27.2207L131.52 20.6531L124.952 14.0856L118.385 20.6532Z" stroke="white" stroke-width="1.52286" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M118.378 7.53111L124.945 14.0986L131.513 7.53113L124.945 0.963614L118.378 7.53111Z" stroke="white" stroke-width="1.52286" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M111.813 14.1014L105.246 20.6689L111.813 27.2365L118.381 20.669L111.813 14.1014Z" stroke="white" stroke-width="1.52286" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M138.081 14.0956L131.514 20.6631L138.081 27.2307L144.649 20.6631L138.081 14.0956Z" stroke="white" stroke-width="1.52286" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M1.08447 27.2192H98.6899L105.247 20.6626L98.6899 14.0967H47.5054" stroke="white" stroke-width="1.52286" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M249.245 27.2192H151.207L144.642 20.6626L151.207 14.0967H202.833" stroke="white" stroke-width="1.52286" stroke-linecap="round" stroke-linejoin="round"/>
    </g>
    <defs>
        <clipPath id="clip0_17374_13644">
        <rect width="250" height="28.0935" fill="white" transform="translate(0.165039 0.0439453)"/>
        </clipPath>
    </defs>
</svg>