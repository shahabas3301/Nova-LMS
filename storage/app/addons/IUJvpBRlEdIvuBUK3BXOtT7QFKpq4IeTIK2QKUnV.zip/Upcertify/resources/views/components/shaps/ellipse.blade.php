<svg xmlns="http://www.w3.org/2000/svg" width="66" height="66" viewBox="0 0 66 66" fill="none">
<circle cx="33.1651" cy="32.7203" r="32.5123" fill="#D9D9D9"/>
</svg>