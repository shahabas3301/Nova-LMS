<svg xmlns="http://www.w3.org/2000/svg" width="31" height="31" viewBox="0 0 31 31" fill="none">
  <path d="M15.5835 10.5V15.5L19.3335 18M15.5835 28C8.67994 28 3.0835 22.4036 3.0835 15.5C3.0835 8.59644 8.67994 3 15.5835 3C22.4871 3 28.0835 8.59644 28.0835 15.5C28.0835 22.4036 22.4871 28 15.5835 28Z" stroke="#D9D9D9" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>