<div class="uc-emptycard">
    <img src="{{ asset('modules/upcertify/images/emptyicon.svg') }}" alt="img description">
    <h3>{{ __('upcertify::upcertify.no_data_found') }}</h3>
    <p>{{ __('upcertify::upcertify.oops_its_seem') }}</p>
</div>