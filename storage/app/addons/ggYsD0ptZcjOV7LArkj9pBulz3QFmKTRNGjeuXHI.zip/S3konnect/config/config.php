<?php

return [
    'name' => 'S3konnect',
];
